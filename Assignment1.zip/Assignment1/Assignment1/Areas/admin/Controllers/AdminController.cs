﻿using Microsoft.AspNetCore.Mvc;

namespace Assignment1.Areas.Admin.Controllers
{
    public class AdminController : Controller
    {
        
        public IActionResult Adminpage()
        {
            return View("~/Areas/admin/Views/Home/Adminpage.cshtml");
        }
        public IActionResult Login()
        {
            return View("~/Areas/admin/Views/Admin/Login.cshtml");
        }
    }
}
