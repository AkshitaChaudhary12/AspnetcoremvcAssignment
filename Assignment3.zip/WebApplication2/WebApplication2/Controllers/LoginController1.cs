﻿using Microsoft.AspNetCore.Mvc;

namespace WebApplication2.Controllers
{
    public class LoginController1 : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Index( string Username,string Password,string confirmPasssword, string Email, string Contact, string Gender ,string Command)
        {

            if(Command=="submit")
            {

            }
            else
            {

            }
            return View();
        }
    }
}
